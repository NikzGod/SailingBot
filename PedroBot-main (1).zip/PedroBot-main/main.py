import logging
import os
import threading
import asyncio
from http.server import HTTPServer, BaseHTTPRequestHandler
from plugins.config import Config
from plugins.database import db
from pyrogram.client import Client

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

logging.getLogger("pyrogram").setLevel(logging.INFO)
logging.getLogger("pymongo").setLevel(logging.WARNING)


class HealthCheckHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        self.send_response(200)
        self.send_header('Content-type', 'text/html')
        self.end_headers()
        self.wfile.write(b'Bot is running!')
        
    def log_message(self, format, *args):
        pass

def run_health_server():
    port = int(os.getenv('PORT', 8080))
    server = HTTPServer(('0.0.0.0', port), HealthCheckHandler)
    logger.info(f"Health check server starting on port {port}")
    server.serve_forever()


async def init_db():
    await db.connect()

def main():
    try:
        plugins = dict(root="plugins")
        
        app = Client(
            "LuffyBot",
            bot_token=Config.BOT_TOKEN,
            api_id=Config.API_ID,
            api_hash=Config.API_HASH,
            plugins=plugins
        )

        health_thread = threading.Thread(target=run_health_server, daemon=True)
        health_thread.start()
        
        print("🚀 LuffyBot is starting...")
        logger.info("Bot is starting...")
        
        loop = asyncio.get_event_loop()
        loop.run_until_complete(init_db())
        
        print("✅ I AM ALIVE @LuffyBot")
        logger.info("Bot is running successfully!")
        app.run()
            
    except Exception as e:
        logger.error(f"Failed to start bot: {str(e)}")
        print(f"❌ Bot failed to start: {str(e)}")
        raise


if __name__ == "__main__":
    main()
