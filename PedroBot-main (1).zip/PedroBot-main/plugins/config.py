"""
Configuration module for LuffyBot.
Handles all environment variables and bot settings.
"""

import os
import logging

logger = logging.getLogger(__name__)


class Config:
    """Configuration class for bot settings."""
    
    BOT_TOKEN = os.getenv("BOT_TOKEN", "")
    API_ID = int(os.getenv("API_ID", "0"))
    API_HASH = os.getenv("API_HASH", "")
    
    BOT_USERNAME = os.getenv("BOT_USERNAME", "YourBot")
    OWNER_ID = int(os.getenv("OWNER_ID", "0"))
    
    UPDATES_CHANNEL = os.getenv("UPDATES_CHANNEL", "")
    LOG_CHANNEL = os.getenv("LOG_CHANNEL", "")
    PAYMENT_LOG = os.getenv("PAYMENT_LOG", "")
    
    MONGO_URI = os.getenv("MONGO_URI", "") or os.getenv("DATABASE_URL", "")
    DATABASE_URL = MONGO_URI
    
    ENABLE_LOGGING = os.getenv("ENABLE_LOGGING", "true").lower() == "true"
    
    @classmethod
    def validate_config(cls):
        """Validate essential configuration parameters."""
        errors = []
        
        if not cls.BOT_TOKEN:
            errors.append("BOT_TOKEN is required")
            
        if cls.API_ID == 0:
            errors.append("API_ID is required")
            
        if not cls.API_HASH:
            errors.append("API_HASH is required")
            
        if errors:
            error_msg = "Configuration errors found:\n" + "\n".join(f"- {error}" for error in errors)
            logger.error(error_msg)
            raise ValueError(error_msg)
            
        logger.info("Configuration validation passed")
        return True


try:
    Config.validate_config()
except Exception as e:
    logger.warning(f"Configuration validation failed: {e}")
