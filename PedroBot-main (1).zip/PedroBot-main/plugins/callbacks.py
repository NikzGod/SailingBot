"""
Callback handlers for LuffyBot.
Handles all inline keyboard button callbacks and user interactions.
"""

import os
import random
import logging
from plugins.config import Config
from plugins.script import Translation
from plugins.info import PICS, QR_PIC, DONE_PIC
from plugins.database import db
from plugins.receipt_generator import generate_receipt_pdf
from pyrogram import enums, filters
from pyrogram.client import Client
from pyrogram.types import InputMediaPhoto, CallbackQuery
from pyrogram.errors import MessageNotModified

logger = logging.getLogger(__name__)

@Client.on_callback_query()
async def button(bot: Client, update: CallbackQuery):
    """Handle all callback queries from inline keyboards."""
    try:
        if update.data == "home":
            await update.message.edit_text(
                text=Translation.START_TEXT.format(update.from_user.mention),
                reply_markup=Translation.START_BUTTONS,
                disable_web_page_preview=True
            )
            
        elif update.data == "demopic":
            await bot.send_photo(
                chat_id=update.message.chat.id,
                photo=Translation.DEMO_PIC,
                caption=Translation.DEMO_TEXT,
            )
            
        elif str(update.data).startswith("accept"):
            user_id = int(str(update.data).split('_')[1])
            
            payment_info = await db.get_user_payment_info(user_id)
            order_id = payment_info.get('order_id', 'N/A') if payment_info else 'N/A'
            
            user_info = await db.users.find_one({'user_id': user_id}) if db.users is not None else None
            username = user_info.get('username') if user_info else None
            first_name = user_info.get('first_name', 'User') if user_info else 'User'
            
            await db.grant_premium(user_id=user_id)
            await db.update_payment_status(user_id=user_id, status='accepted')
            
            pdf_path = await generate_receipt_pdf(
                user_id=user_id,
                username=username or 'N/A',
                first_name=first_name,
                order_id=order_id,
                amount=100
            )
            
            if pdf_path and os.path.exists(pdf_path):
                try:
                    await bot.send_document(
                        chat_id=user_id,
                        document=pdf_path,
                        caption=f"**🎉 Payment Receipt**\n\n**Order ID:** `{order_id}`\n\nThank you for your purchase! 💎"
                    )
                    
                    if Config.PAYMENT_LOG:
                        try:
                            await bot.send_document(
                                chat_id=Config.PAYMENT_LOG,
                                document=pdf_path,
                                caption=f"✅ **Payment Accepted**\n\n"
                                        f"**Order ID:** `{order_id}`\n"
                                        f"**User ID:** `{user_id}`\n"
                                        f"**Name:** {first_name}\n"
                                        f"**Username:** @{username or 'N/A'}\n"
                                        f"**Status:** Completed ✅"
                            )
                            logger.info(f"Receipt for order {order_id} sent to LOG_CHANNEL")
                        except Exception as log_error:
                            logger.error(f"Error sending receipt to LOG_CHANNEL: {str(log_error)}")
                    
                    os.remove(pdf_path)
                except Exception as e:
                    logger.error(f"Error sending receipt PDF: {str(e)}")
            
            await bot.send_message(chat_id=user_id, text=Translation.ADMINI_ACCEPTED, reply_markup=Translation.LINK_BUTTONS)
            await update.message.edit_caption(caption=Translation.SUCCESSFULLY_ACCEPTED)
            logger.info(f"Premium access granted to user {user_id} with order_id {order_id}")

        elif str(update.data).startswith("decline"):
            user_id = int(str(update.data).split('_')[1])
            
            await db.update_payment_status(user_id=user_id, status='declined')
            
            await bot.send_message(chat_id=user_id, text=Translation.PAYMENT_DECLINED, reply_markup=Translation.ADMIN_BUTTONS)
            await update.message.edit_caption(caption=Translation.DECLINED_SUCCESSFULLY)
            logger.info(f"Payment declined for user {user_id}")
            
        elif update.data == "premium":
            await update.edit_message_media(
                InputMediaPhoto(
                    random.choice(PICS), 
                    Translation.DETAILS_TEXT.format(update.from_user.mention), 
                    enums.ParseMode.HTML
                ), 
                reply_markup=Translation.PREMIUM_BUTTONS
            )
            
        elif update.data == "payment":
            await update.edit_message_media(
                InputMediaPhoto(
                    random.choice(QR_PIC), 
                    Translation.QR_TEXT, 
                    enums.ParseMode.HTML
                ), 
                reply_markup=Translation.BUTTONS
            )
          
        elif update.data == "paid":
            await update.edit_message_media(
                InputMediaPhoto(
                    random.choice(DONE_PIC), 
                    Translation.PAID_TEXT, 
                    enums.ParseMode.HTML
                ), 
                reply_markup=Translation.PAID_BUTTONS
            )
            
        elif update.data == "check_sub":
            from plugins.functions.forcesub import handle_force_subscribe
            
            result = await handle_force_subscribe(bot, update)
            if result == 200:
                await update.message.edit_text(
                    text=Translation.START_TEXT.format(update.from_user.mention),
                    reply_markup=Translation.START_BUTTONS,
                    disable_web_page_preview=True
                )
                await update.answer("✅ Welcome! You can now use the bot.", show_alert=False)
            else:
                await update.answer("❌ Please join the channel first!", show_alert=True)
            
        elif str(update.data) == "close":
            await update.message.delete(True)
            
    except MessageNotModified:
        await update.answer("Nothing to update!", show_alert=False)
    except Exception as e:
        logger.error(f"Error in callback handler: {str(e)}")
        await update.answer("❌ An error occurred. Please try again.", show_alert=True)
