"""
Invite command plugin for LuffyBot.
Handles /invite command to generate referral links.
"""

import logging
from pyrogram import filters
from pyrogram.client import Client
from pyrogram.types import InlineKeyboardButton, InlineKeyboardMarkup
from plugins.config import Config

logger = logging.getLogger(__name__)


@Client.on_message(filters.private & filters.command(["invite"]))
async def refer(client, message):
    """Handle /invite command to generate referral link."""
    reply_markup = InlineKeyboardMarkup(
        [[InlineKeyboardButton("📡 Sʜᴀʀᴇ Yᴏᴜʀ Lɪɴᴋ", url=f"https://t.me/share/url?url=https://t.me/{Config.BOT_USERNAME}?start={message.from_user.id}")]]
    )
    
    invite_text = f"""
<b>👥 Iɴᴠɪᴛᴇ Yᴏᴜʀ Fʀɪᴇɴᴅs 🫶

Hᴇʏ {message.from_user.mention}! 

Sʜᴀʀᴇ ᴛʜɪs ʙᴏᴛ ᴡɪᴛʜ ʏᴏᴜʀ ғʀɪᴇɴᴅs ᴀɴᴅ ʟᴇᴛ ᴛʜᴇᴍ ᴇɴᴊᴏʏ ᴏᴜʀ sᴇʀᴠɪᴄᴇs! 🌟

Yᴏᴜʀ Rᴇғᴇʀʀᴀʟ Lɪɴᴋ 👇
<code>https://t.me/{Config.BOT_USERNAME}?start={message.from_user.id}</code>

Cʟɪᴄᴋ ᴛʜᴇ ʙᴜᴛᴛᴏɴ ʙᴇʟᴏᴡ ᴛᴏ sʜᴀʀᴇ! 📤</b>
"""
    
    await message.reply_text(
        text=invite_text,
        reply_markup=reply_markup,
    )
    
    logger.info(f"Invite command handled for user: {message.from_user.id}")
