"""
Script module for LuffyBot.
Contains translation strings and UI elements.
"""

from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton

class Translation(object):

    START_TEXT = """
    <b>𝐇𝐄𝐋𝐋𝐎 {} 😍👋,
𝗦𝗲𝗹𝗲𝗰𝘁 𝗧𝗵𝗲 𝗚𝗥𝗢𝗨𝗣 𝗬𝗢𝗨 𝗪𝗔𝗡𝗧🌺‼️

നിങ്ങൾക് ഇഷ്ടമുള്ള ഗ്രുപ്പ് select ചെയ്യുക.!!!</b>
"""
    DETAILS_TEXT = """
<b>Hᴇʏ {} 🫦

» സ്വർഗവാതിൽ 🔕

✅ • Daily Videos Updated
✅ • iOS supported
✅ • Full Direct Videos
✅ • Rare Collections & Hot Collections
✅ • Mallu aunty, Girls, etc… available

📌 ഗ്രൂപ്പ് Ban ആക്കുന്നതുവരെ മെമ്പർഷിപ്പ് ഉണ്ടയിരിക്കും

Group Names 👇
രോമാഞ്ചം 🔕
സ്വർഗവാതിൽ 🔕
മാണിക്യം 🔕

Price: 100

Click Pay Button, Pay The Amount And JOIN 🫦</b>
"""
    ABOUT_TEXT = """
**Mʏ ɴᴀᴍᴇ** : [ᴜᴘʟᴏᴀᴅᴇʀ ʙᴏᴛ ᴠ4](https://t.me/UploadLinkToFileBot)

**Sᴏᴜʀᴄᴇ** : [ᴄʟɪᴄᴋ ʜᴇʀᴇ](https://github.com/LISA-KOREA/UPLOADER-BOT-V4)

**Dᴀᴛᴀʙᴀsᴇ** : [MᴏɴɢᴏDB](https://cloud.mongodb.com)

**Lᴀɴɢᴜᴀɢᴇ :** [Pʏᴛʜᴏɴ 3.12.3](https://www.python.org/)

**Fʀᴀᴍᴇᴡᴏʀᴋ :** [ᴘʏʀᴏɢᴀᴍ 2.0.106](https://docs.pyrogram.org/)

**Dᴇᴠᴇʟᴏᴘᴇʀ :** @Luffy
"""
    INFO_TXT = """<i>
<u>Yᴏᴜʀ Dᴇᴛᴀɪʟꜱ</u>

○ ID : <code>{id}</code>
○ DC : <code>{dc}</code>
○ First Name : <code>{n}</code>
○ UserName : @{u}
○ link : <code>https://t.me/{u}</code>

Thank You For Using Me❣️</i>"""

    INVITE_TEXT = "**INVITE YOUR FRIENDS 🫶**"

    QR_TEXT = """
    <b>Pᴀʏ Aɴᴅ Sᴇɴᴅ Sᴄʀᴇᴇɴꜱʜᴏᴛ 

    പേയ്‌മെന്റ് ചെയ്യുക എന്നിട്ട് Screenshot ഇതിലേക്ക് അയക്കുക 

ചെയ്യാൻ അറിയില്ലെങ്കിൽ @imPedrin ഇതിൽ മെസ്സേജ് അയക്കുക 🤲
    

Dɪʀᴇᴄᴛ Pᴀʏ: t.me/imPedrin</b>
    """

    ADS_TEXT = """
    **[Must Watch 🔥](https://t.me/+yxNSj8_0_7dlMTVh)**
    """

    STATUS_TXT = """<b>◉ ᴛᴏᴛᴀʟ ꜰɪʟᴇꜱ: <code>{}</code>
◉ ᴛᴏᴛᴀʟ ᴜꜱᴇʀꜱ: <code>{}</code>  
◉ ᴛᴏᴛᴀʟ ᴄʜᴀᴛꜱ: <code>{}</code>
◉ ᴜꜱᴇᴅ ᴅʙ ꜱɪᴢᴇ: <code>{}</code>
◉ ꜰᴇᴇᴇ ᴅʙ ꜱɪᴢᴇ: <code>{}</code></b>"""

    PROGRESS = """
🏎️ Sᴘᴇᴇᴅ : {3}/s\n\n
✅ Dᴏɴᴇ : {1}\n\n
🟰 Tᴏᴛᴀʟ sɪᴢᴇ  : {2}\n\n
⏳ Tɪᴍᴇ ʟᴇғᴛ : {4}\n\n
"""

    DEMO_TEXT = """
    <b>☝️DEMO OF രോമാഞ്ചം പ്രീമിയം 🔞</b>
    """

    PAID_TEXT = """
    💁🏻‍♂️ <b>Have you paid?</b>

👌🏻 <b>Then</b> <code>send here a picture (not a document!) a receipt of payment: a screenshot or a photo.</code>

The receipt must clearly show: <b>date, time and amount of payment.</b>
__________________________
<b>You can be blocked for spam!</b>
    """
    
    PAYMENT_INFO = """
○ ID : <code>{id}</code>    
○ First Name : <code>{n}</code>
○ UserName : @{u}
○ link : <code>https://t.me/{u}</code>
    """
    
    ADMINI_ACCEPTED = """
    🎉 Your Payment Has Been Accepted!
    
Thank You For Your Purchase.
Welcome To പാൽക്കുടം പ്രീമിയം 🔞

✅ Your Premium Membership Is Now Active
✅ Click The Button Below To Join The Group
✅ Your Access Will Remain Until The Group Is Banned

If You Have Any Issues Accessing The Group, Please Contact Support.
    """
    
    SUCCESSFULLY_ACCEPTED = """
    Successfully Send Accept Message To User
    """

    PAYMENT_DECLINED = """
    <b>Your Transaction Is Declined! Your Payment Is Not Received. Contact Admin</b>
    """

    DECLINED_SUCCESSFULLY = """
    Successfully Send Decline Message To User
    """

    PAYMENT_USER = """
**Nᴇᴡ Pʀᴇᴍɪᴜᴍ Mᴇᴍʙᴇʀ**
○ ID : <code>{id}</code>    
○ First Name : <code>{n}</code>
○ UserName : @{u}
○ link : <code>https://t.me/{u}</code>
    """

    PIC = "https://telegra.ph/file/601e19ea5b1d5c1816a85-c800a42e2fae77b6c3.jpg"

    PAYMENT_QR = "https://telegra.ph/file/5fdf6b056f45c7f222e2e-b284c5fcfc271ba13e.jpg"

    DEMO_PIC = "https://telegra.ph/file/.jpg"
    
    START_BUTTONS = InlineKeyboardMarkup(
        [[  
        InlineKeyboardButton('സ്വർഗവാതിൽ 🔕', callback_data='premium')
        ],[
        InlineKeyboardButton('✘ Cʟᴏsᴇ', callback_data='close')
        ]]
    )
    PREMIUM_BUTTONS = InlineKeyboardMarkup(
        [[
        InlineKeyboardButton('💰 Pᴀʏ 100', callback_data='payment')
        ],[
         InlineKeyboardButton('Dᴇᴍᴏ', url='https://t.me/+sHwBF-NuKB8yZTM1')
        ],[ 
        InlineKeyboardButton('« Bᴀᴄᴋ', callback_data='home'),   
        InlineKeyboardButton('✘ Cʟᴏsᴇ', callback_data='close')
        ]]
    )
    BUTTONS = InlineKeyboardMarkup(
        [[
        InlineKeyboardButton('⏳I PAID', callback_data='paid')           
        ],[
        InlineKeyboardButton('« Bᴀᴄᴋ', callback_data='premium'),       
        InlineKeyboardButton('✘ Cʟᴏsᴇ', callback_data='close')
        ]]
    )
    INVITE_BUTTONS = InlineKeyboardMarkup(
        [[
        InlineKeyboardButton('↗️ Sʜᴀʀᴇ Yᴏᴜʀ Lɪɴᴋ', url='https://t.me/share/url?url=https://t.me/Lufffybro_bot?start={message.from_user.id}')           
        ]]
    )
    ADMIN_BUTTONS = InlineKeyboardMarkup(
        [[
        InlineKeyboardButton('👤 Cᴏɴᴛᴀᴄᴛ Aᴅᴍɪɴ', url='https://t.me/PedroSir')           
        ]]
    )
    LINK_BUTTONS = InlineKeyboardMarkup(
        [[
        InlineKeyboardButton('Click Here', url='https://t.me/PedroPremiumBot?start=BQADAQADvhAAAlfs2EcOR9zCMt4AAZMWBA')
        ]]
    )
    PAID_BUTTONS = InlineKeyboardMarkup(
        [[
        InlineKeyboardButton('✘ Cʟᴏsᴇ', callback_data='close')           
        ]]
    )
