"""
Database module for LuffyBot.
Handles MongoDB operations for user tracking and premium management.
"""

import logging
from datetime import datetime
from motor.motor_asyncio import AsyncIOMotorClient
from plugins.config import Config

logger = logging.getLogger(__name__)


class Database:
    def __init__(self):
        self.client = None
        self.db = None
        self.users = None
        self.premium = None
        self.payments = None
        
    async def connect(self):
        """Connect to MongoDB database."""
        try:
            if not Config.MONGO_URI:
                logger.warning("MONGO_URI not configured, database features disabled")
                return False
                
            self.client = AsyncIOMotorClient(Config.MONGO_URI)
            self.db = self.client['LuffyBot']
            self.users = self.db['users']
            self.premium = self.db['premium_users']
            self.payments = self.db['payments']
            
            await self.client.admin.command('ping')
            
            await self.payments.create_index([
                ('user_id', 1),
                ('status', 1),
                ('timestamp', -1)
            ])
            
            logger.info("Connected to MongoDB successfully!")
            return True
        except Exception as e:
            logger.error(f"Failed to connect to MongoDB: {str(e)}")
            return False
    
    async def add_user(self, user_id: int, username: str = None, first_name: str = None):
        """Add a new user to the database."""
        try:
            if self.users is None:
                return False
                
            user_data = {
                'user_id': user_id,
                'username': username,
                'first_name': first_name,
                'joined_date': datetime.now(),
                'last_seen': datetime.now()
            }
            
            await self.users.update_one(
                {'user_id': user_id},
                {'$set': user_data},
                upsert=True
            )
            logger.info(f"User {user_id} added/updated in database")
            return True
        except Exception as e:
            logger.error(f"Error adding user to database: {str(e)}")
            return False
    
    async def update_last_seen(self, user_id: int):
        """Update user's last seen timestamp."""
        try:
            if self.users is None:
                return False
                
            await self.users.update_one(
                {'user_id': user_id},
                {'$set': {'last_seen': datetime.now()}}
            )
            return True
        except Exception as e:
            logger.error(f"Error updating last seen: {str(e)}")
            return False
    
    async def grant_premium(self, user_id: int, username: str = None):
        """Grant premium access to a user."""
        try:
            if self.premium is None:
                return False
                
            premium_data = {
                'user_id': user_id,
                'username': username,
                'granted_date': datetime.now(),
                'status': 'active'
            }
            
            await self.premium.update_one(
                {'user_id': user_id},
                {'$set': premium_data},
                upsert=True
            )
            logger.info(f"Premium granted to user {user_id}")
            return True
        except Exception as e:
            logger.error(f"Error granting premium: {str(e)}")
            return False
    
    async def revoke_premium(self, user_id: int):
        """Revoke premium access from a user."""
        try:
            if self.premium is None:
                return False
                
            await self.premium.update_one(
                {'user_id': user_id},
                {'$set': {'status': 'revoked', 'revoked_date': datetime.now()}}
            )
            logger.info(f"Premium revoked for user {user_id}")
            return True
        except Exception as e:
            logger.error(f"Error revoking premium: {str(e)}")
            return False
    
    async def is_premium(self, user_id: int):
        """Check if a user has premium access."""
        try:
            if self.premium is None:
                return False
                
            user = await self.premium.find_one({
                'user_id': user_id,
                'status': 'active'
            })
            return user is not None
        except Exception as e:
            logger.error(f"Error checking premium status: {str(e)}")
            return False
    
    async def log_payment(self, user_id: int, username: str = None, status: str = 'pending', order_id: str = None):
        """Log a payment attempt."""
        try:
            if self.payments is None:
                return False
                
            payment_data = {
                'user_id': user_id,
                'username': username,
                'status': status,
                'order_id': order_id,
                'timestamp': datetime.now()
            }
            
            result = await self.payments.insert_one(payment_data)
            logger.info(f"Payment logged for user {user_id} with status {status} and order_id {order_id}")
            return result.inserted_id
        except Exception as e:
            logger.error(f"Error logging payment: {str(e)}")
            return None
    
    async def update_payment_status(self, user_id: int, status: str):
        """Update payment status for the most recent pending payment (accepted/declined)."""
        try:
            if self.payments is None:
                return False
                
            result = await self.payments.find_one_and_update(
                {'user_id': user_id, 'status': 'pending'},
                {'$set': {'status': status, 'updated_at': datetime.now()}},
                sort=[('timestamp', -1), ('_id', -1)]
            )
            
            if result:
                logger.info(f"Payment status updated to {status} for user {user_id}")
                return True
            else:
                logger.warning(f"No pending payment found for user {user_id}")
                return False
        except Exception as e:
            logger.error(f"Error updating payment status: {str(e)}")
            return False
    
    async def get_user_payment_info(self, user_id: int):
        """Get the most recent payment information for a user."""
        try:
            if self.payments is None:
                return None
                
            payment = await self.payments.find_one(
                {'user_id': user_id},
                sort=[('timestamp', -1), ('_id', -1)]
            )
            return payment
        except Exception as e:
            logger.error(f"Error getting payment info: {str(e)}")
            return None
    
    async def get_total_users(self):
        """Get total number of users."""
        try:
            if self.users is None:
                return 0
            return await self.users.count_documents({})
        except Exception as e:
            logger.error(f"Error getting total users: {str(e)}")
            return 0
    
    async def get_total_premium(self):
        """Get total number of premium users."""
        try:
            if self.premium is None:
                return 0
            return await self.premium.count_documents({'status': 'active'})
        except Exception as e:
            logger.error(f"Error getting total premium users: {str(e)}")
            return 0
    
    async def is_user_exist(self, user_id: int):
        """Check if a user exists in the database."""
        try:
            if self.users is None:
                return False
            user = await self.users.find_one({'user_id': int(user_id)})
            return bool(user)
        except Exception as e:
            logger.error(f"Error checking user existence: {str(e)}")
            return False
    
    async def total_users_count(self):
        """Get total number of users (alias for get_total_users)."""
        return await self.get_total_users()
    
    async def get_all_users(self):
        """Get all users as an async cursor."""
        try:
            if self.users is None:
                return []
            return self.users.find({})
        except Exception as e:
            logger.error(f"Error getting all users: {str(e)}")
            return []
    
    async def delete_user(self, user_id: int):
        """Delete a user from the database."""
        try:
            if self.users is None:
                return False
            await self.users.delete_many({'user_id': int(user_id)})
            logger.info(f"User {user_id} deleted from database")
            return True
        except Exception as e:
            logger.error(f"Error deleting user: {str(e)}")
            return False
    
    async def close(self):
        """Close database connection."""
        if self.client:
            self.client.close()
            logger.info("MongoDB connection closed")


db = Database()
