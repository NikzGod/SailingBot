"""
Stats command plugin for LuffyBot.
Handles /stats command to show bot statistics (owner only).
"""

import logging
from pyrogram import filters
from pyrogram.client import Client
from plugins.config import Config
from plugins.database import db

logger = logging.getLogger(__name__)


@Client.on_message(filters.private & filters.command("stats"))
async def status(bot, update):
    """Handle /stats command to show bot statistics."""
    if update.from_user.id != Config.OWNER_ID:
        return
    
    total_users = await db.total_users_count()
    premium_users = await db.get_total_premium()
    free_users = total_users - premium_users
    
    stats_text = f"""
<b>📊 Bᴏᴛ Sᴛᴀᴛɪsᴛɪᴄs 📊

╭─────────────────────╮
│ 👥 Usᴇʀ Sᴛᴀᴛs
╰─────────────────────╯

• Tᴏᴛᴀʟ Usᴇʀs: <code>{total_users}</code>
• 💎 Pʀᴇᴍɪᴜᴍ Mᴇᴍʙᴇʀs: <code>{premium_users}</code>
• 🆓 Fʀᴇᴇ Usᴇʀs: <code>{free_users}</code>

╭─────────────────────╮
│ ⚙️ Bᴏᴛ Iɴғᴏ
╰─────────────────────╯

• 🤖 Bᴏᴛ: @{Config.BOT_USERNAME}
• 👤 Oᴡɴᴇʀ: {update.from_user.mention}
• ✅ Sᴛᴀᴛᴜs: <code>Rᴜɴɴɪɴɢ 🚀</code>

━━━━━━━━━━━━━━━━━━━━</b>
"""
    
    await update.reply_text(
        text=stats_text,
        quote=True,
        disable_web_page_preview=True
    )
    
    logger.info(f"Stats command handled for owner: {update.from_user.id}")
