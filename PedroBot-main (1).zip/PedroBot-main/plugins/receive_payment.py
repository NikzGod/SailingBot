"""
Payment proof reception and verification for LuffyBot.
Handles user photo submissions for payment verification.
"""

import logging
from pyrogram import filters, enums
from pyrogram.client import Client
from plugins.config import Config
from plugins.script import Translation
from plugins.database import db
from plugins.receipt_generator import generate_order_id
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton

logger = logging.getLogger(__name__)


@Client.on_message(filters.private & filters.photo)
async def check_photo(c, m):
    """Handle photo submissions for payment proof verification."""
    try:
        ff = m.from_user
        
        order_id = generate_order_id()
        
        await db.log_payment(
            user_id=ff.id,
            username=ff.username,
            status='pending',
            order_id=order_id
        )
        
        await m.reply_text(
            f"**Your Proof Is Submitted ✅**\n\n"
            f"**Order ID:** `{order_id}`\n\n"
            f"**Admin Will Verify Within Minutes**"
        )
        
        button = [[
            InlineKeyboardButton("Accept", callback_data=f"accept_{m.from_user.id}"),
            InlineKeyboardButton("Decline", callback_data=f"decline_{m.from_user.id}")
        ]]
        
        try:
            await c.send_photo(
                chat_id=Config.OWNER_ID, 
                photo=m.photo.file_id, 
                caption=Translation.PAYMENT_INFO.format(
                    id=ff.id, 
                    n=ff.first_name, 
                    u=ff.username or "N/A"
                ) + f"\n\n**Order ID:** `{order_id}`", 
                reply_markup=InlineKeyboardMarkup(button), 
                parse_mode=enums.ParseMode.HTML
            )
            
            await c.send_message(
                chat_id=Config.OWNER_ID, 
                text=Translation.PAYMENT_USER.format(
                    id=ff.id, 
                    n=ff.first_name, 
                    u=ff.username or "N/A"
                )
            )
            
            logger.info(f"Payment proof submitted by user {ff.id} and sent to admin {Config.OWNER_ID}")
            
            if Config.LOG_CHANNEL:
                try:
                    await c.send_message(
                        chat_id=Config.LOG_CHANNEL,
                        text=f"📋 **New Payment Submission**\n\n"
                             f"**Order ID:** `{order_id}`\n"
                             f"**User ID:** `{ff.id}`\n"
                             f"**Name:** {ff.first_name}\n"
                             f"**Username:** @{ff.username or 'N/A'}\n"
                             f"**Status:** Pending ⏳"
                    )
                    logger.info(f"Order ID {order_id} logged to LOG_CHANNEL")
                except Exception as log_error:
                    logger.error(f"Error logging to LOG_CHANNEL: {str(log_error)}")
            
        except Exception as e:
            logger.error(f"Error sending payment proof to admin: {str(e)}")
            try:
                if Config.PAYMENT_LOG:
                    await c.send_photo(
                        chat_id=Config.PAYMENT_LOG, 
                        photo=m.photo.file_id, 
                        caption=Translation.PAYMENT_INFO.format(
                            id=ff.id, 
                            n=ff.first_name, 
                            u=ff.username or "N/A"
                        ), 
                        reply_markup=InlineKeyboardMarkup(button), 
                        parse_mode=enums.ParseMode.HTML
                    )
                    logger.info(f"Payment proof sent to PAYMENT_LOG channel as fallback")
            except Exception as fallback_error:
                logger.error(f"Fallback also failed: {str(fallback_error)}")
            
    except Exception as e:
        logger.error(f"Error processing payment proof: {str(e)}")
        await m.reply_text("❌ Error processing your payment proof. Please try again.")
