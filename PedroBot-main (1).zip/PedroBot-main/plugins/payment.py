"""
Payment command plugin for LuffyBot.
Handles payment flow and QR code display for premium subscriptions.
"""

import logging
from pyrogram import filters
from pyrogram.client import Client
from plugins.config import Config
from plugins.script import Translation
from plugins.functions.forcesub import handle_force_subscribe

logger = logging.getLogger(__name__)


@Client.on_message(filters.command(["payment"]) & filters.private)
async def payment_command(bot, update):
    """Handle /payment command for premium subscription."""
    try:
        if not update.from_user:
            return await update.reply_text("I don't know about you sar :(")
        
        if Config.LOG_CHANNEL and Config.LOG_CHANNEL not in ["", "0"]:
            try:
                await bot.send_message(
                    Config.LOG_CHANNEL,
                    f"#PAYMENT💰 : \n\nPay Button Clicked [{update.from_user.first_name}](tg://user?id={update.from_user.id})\n 💰 Payment @{Config.BOT_USERNAME}!!"
                )
            except Exception as e:
                logger.warning(f"Could not send to log channel: {str(e)}")
        
        if Config.UPDATES_CHANNEL and Config.UPDATES_CHANNEL not in ["", "0"]:
            fsub = await handle_force_subscribe(bot, update)
            if fsub == 400:
                return
        
        await update.reply_photo(
            photo=Translation.PAYMENT_QR,
            caption=Translation.QR_TEXT.format(update.from_user.mention),
            reply_markup=Translation.BUTTONS
        )
        
        logger.info(f"Payment command handled for user: {update.from_user.id}")
        
    except Exception as e:
        logger.error(f"Error in payment command: {str(e)}")
        await update.reply_text("❌ An error occurred while processing your payment request. Please try again later.")
