"""
Information module for LuffyBot.
Contains image URLs and media constants.
"""

PICS = [
    "https://telegra.ph/file/601e19ea5b1d5c1816a85-c800a42e2fae77b6c3.jpg",
]

QR_PIC = [
    "https://envs.sh/lXF.jpg",
]

DONE_PIC = [
    "https://telegra.ph/file/db9b005b9c2e2d005e702-542a14d66a46596274.jpg",
]

PIC = "https://telegra.ph/file/601e19ea5b1d5c1816a85-c800a42e2fae77b6c3.jpg"
