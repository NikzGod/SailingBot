"""
Plugin system for LuffyBot.
This package contains all the modular functionality for the Telegram bot.
"""

__version__ = "1.0.0"
__author__ = "LuffyBot Team"

from . import start
from . import config
from . import callbacks
from . import script
from . import info
from . import payment
from . import receive_payment
from . import database
from . import broadcast
from . import userinfo
from . import stats
from . import invite

__all__ = [
    'start',
    'config',
    'callbacks',
    'script',
    'info',
    'payment',
    'receive_payment',
    'database',
    'broadcast',
    'userinfo',
    'stats',
    'invite'
]
