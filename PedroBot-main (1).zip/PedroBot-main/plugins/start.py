"""
Start command plugin for LuffyBot.
Handles /start command and welcome messages.
"""

import asyncio
import logging
from pyrogram import filters
from pyrogram.client import Client
from plugins.config import Config
from plugins.script import Translation
from plugins.database import db
from plugins.functions.forcesub import handle_force_subscribe

logger = logging.getLogger(__name__)


@Client.on_message(filters.command(["start"]) & filters.private)
async def start(bot, update):
    if not update.from_user:
        return await update.reply_text("I don't know about you sar :(")
    
    await db.add_user(
        user_id=update.from_user.id,
        username=update.from_user.username,
        first_name=update.from_user.first_name
    )
    
    if Config.LOG_CHANNEL and Config.LOG_CHANNEL not in ["", "0"]:
        try:
            await bot.send_message(
                Config.LOG_CHANNEL,
                f"#NEW_USER: \n\n__**○ New User :**__ [{update.from_user.first_name}](tg://user?id={update.from_user.id})\n__**○ Started :**__ @{Config.BOT_USERNAME}!!\n__**○ ID :**__ `{update.from_user.id}`\n__**○ link :**__ <code>https://t.me/{update.from_user.username}</code>"
            )
        except Exception as e:
            logger.warning(f"Could not send to log channel: {str(e)}")
    
    if Config.UPDATES_CHANNEL and Config.UPDATES_CHANNEL not in ["", "0"]:
        fsub = await handle_force_subscribe(bot, update)
        if fsub == 400:
            return       
    
    mkn = await update.reply_sticker("CAACAgIAAxkBAAJbimZctsnmFpfbGwHGEKIRBKId82e4AAJuAAOtZbwUmdKVOaHouYc1BA")  
    await asyncio.sleep(2)
    await mkn.delete()
    await update.reply_photo(
        photo=Translation.PIC,
        caption=Translation.START_TEXT.format(update.from_user.mention),
        reply_markup=Translation.START_BUTTONS
    )
