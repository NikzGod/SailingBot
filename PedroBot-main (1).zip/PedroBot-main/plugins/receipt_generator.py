"""
Receipt Generator for LuffyBot.
Generates PDF receipts for payment confirmations.
"""

import os
import logging
from datetime import datetime
from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.lib.units import inch
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_CENTER, TA_LEFT
from plugins.config import Config

logger = logging.getLogger(__name__)


def generate_order_id():
    """Generate a unique order ID based on timestamp."""
    timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
    import random
    random_num = random.randint(1000, 9999)
    return f"ORD-{timestamp}-{random_num}"


async def generate_receipt_pdf(user_id: int, username: str, first_name: str, order_id: str, amount: int = 100):
    """
    Generate a PDF receipt for payment confirmation.
    
    Args:
        user_id: Telegram user ID
        username: Telegram username
        first_name: User's first name
        order_id: Generated order ID
        amount: Payment amount (default: 100)
    
    Returns:
        str: Path to the generated PDF file
    """
    try:
        os.makedirs("receipts", exist_ok=True)
        
        filename = f"receipts/receipt_{order_id}.pdf"
        doc = SimpleDocTemplate(
            filename, 
            pagesize=letter, 
            topMargin=0.75*inch, 
            bottomMargin=0.75*inch,
            leftMargin=0.75*inch,
            rightMargin=0.75*inch
        )
        story = []
        
        styles = getSampleStyleSheet()
        
        header_style = ParagraphStyle(
            'Header',
            parent=styles['Normal'],
            fontSize=26,
            textColor=colors.HexColor('#1F2937'),
            spaceAfter=8,
            alignment=TA_CENTER,
            fontName='Helvetica-Bold',
            leading=30
        )
        
        subheader_style = ParagraphStyle(
            'SubHeader',
            parent=styles['Normal'],
            fontSize=12,
            textColor=colors.HexColor('#6B7280'),
            spaceAfter=25,
            alignment=TA_CENTER,
            fontName='Helvetica'
        )
        
        header = Paragraph("PAYMENT RECEIPT", header_style)
        story.append(header)
        
        subheader = Paragraph(f"@{Config.BOT_USERNAME} Premium Membership", subheader_style)
        story.append(subheader)
        story.append(Spacer(1, 0.15*inch))
        
        receipt_date = datetime.now().strftime("%B %d, %Y | %I:%M %p")
        
        order_info_data = [
            ['Order Information', ''],
        ]
        order_info_table = Table(order_info_data, colWidths=[3.8*inch])
        order_info_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#6366F1')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 12),
            ('TOPPADDING', (0, 0), (-1, 0), 8),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 8),
            ('LEFTPADDING', (0, 0), (-1, 0), 12),
        ]))
        story.append(order_info_table)
        
        order_details = [
            ['Order ID:', order_id],
            ['Date & Time:', receipt_date],
            ['Payment Status:', '✅ COMPLETED'],
        ]
        order_table = Table(order_details, colWidths=[1.8*inch, 3.2*inch])
        order_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, -1), colors.HexColor('#F9FAFB')),
            ('TEXTCOLOR', (0, 0), (0, -1), colors.HexColor('#374151')),
            ('TEXTCOLOR', (1, 0), (1, -1), colors.HexColor('#1F2937')),
            ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
            ('FONTNAME', (1, 0), (1, -1), 'Helvetica'),
            ('FONTSIZE', (0, 0), (-1, -1), 10),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
            ('LEFTPADDING', (0, 0), (-1, -1), 12),
            ('RIGHTPADDING', (0, 0), (-1, -1), 12),
            ('TOPPADDING', (0, 0), (-1, -1), 8),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 8),
            ('LINEBELOW', (0, 0), (-1, -2), 0.5, colors.HexColor('#E5E7EB')),
            ('TEXTCOLOR', (1, 2), (1, 2), colors.HexColor('#10B981')),
            ('FONTNAME', (1, 2), (1, 2), 'Helvetica-Bold'),
        ]))
        story.append(order_table)
        story.append(Spacer(1, 0.25*inch))
        
        customer_header_data = [
            ['Customer Information', ''],
        ]
        customer_header_table = Table(customer_header_data, colWidths=[3.8*inch])
        customer_header_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#6366F1')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 12),
            ('TOPPADDING', (0, 0), (-1, 0), 8),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 8),
            ('LEFTPADDING', (0, 0), (-1, 0), 12),
        ]))
        story.append(customer_header_table)
        
        customer_details = [
            ['Name:', first_name],
            ['Username:', f"@{username}" if username else "N/A"],
            ['User ID:', str(user_id)],
        ]
        customer_table = Table(customer_details, colWidths=[1.8*inch, 3.7*inch])
        customer_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, -1), colors.HexColor('#F9FAFB')),
            ('TEXTCOLOR', (0, 0), (0, -1), colors.HexColor('#374151')),
            ('TEXTCOLOR', (1, 0), (1, -1), colors.HexColor('#1F2937')),
            ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
            ('FONTNAME', (1, 0), (1, -1), 'Helvetica'),
            ('FONTSIZE', (0, 0), (-1, -1), 10),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
            ('LEFTPADDING', (0, 0), (-1, -1), 12),
            ('RIGHTPADDING', (0, 0), (-1, -1), 12),
            ('TOPPADDING', (0, 0), (-1, -1), 8),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 8),
            ('LINEBELOW', (0, 0), (-1, -2), 0.5, colors.HexColor('#E5E7EB')),
        ]))
        story.append(customer_table)
        story.append(Spacer(1, 0.25*inch))
        
        payment_header_data = [
            ['Payment Summary', ''],
        ]
        payment_header_table = Table(payment_header_data, colWidths=[3.8*inch])
        payment_header_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#6366F1')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 12),
            ('TOPPADDING', (0, 0), (-1, 0), 8),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 8),
            ('LEFTPADDING', (0, 0), (-1, 0), 12),
        ]))
        story.append(payment_header_table)
        
        payment_details = [
            ['Product:', 'Premium Membership'],
            ['Amount Paid:', f'₹{amount}'],
        ]
        payment_table = Table(payment_details, colWidths=[1.8*inch, 3.7*inch])
        payment_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, -1), colors.HexColor('#F9FAFB')),
            ('TEXTCOLOR', (0, 0), (0, -1), colors.HexColor('#374151')),
            ('TEXTCOLOR', (1, 0), (1, -1), colors.HexColor('#1F2937')),
            ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
            ('FONTNAME', (1, 0), (1, -1), 'Helvetica'),
            ('FONTSIZE', (0, 0), (-1, -1), 10),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
            ('LEFTPADDING', (0, 0), (-1, -1), 12),
            ('RIGHTPADDING', (0, 0), (-1, -1), 12),
            ('TOPPADDING', (0, 0), (-1, -1), 8),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 8),
            ('LINEBELOW', (0, 0), (-1, -2), 0.5, colors.HexColor('#E5E7EB')),
            ('TEXTCOLOR', (1, 1), (1, 1), colors.HexColor('#6366F1')),
            ('FONTNAME', (1, 1), (1, 1), 'Helvetica-Bold'),
            ('FONTSIZE', (1, 1), (1, 1), 12),
        ]))
        story.append(payment_table)
        story.append(Spacer(1, 0.35*inch))
        
        footer_text = Paragraph(
            "<b>Thank You for Your Purchase!</b><br/><br/>"
            "Your premium membership has been successfully activated. You now have full access to all premium features and benefits.<br/><br/>"
            "This is an automated receipt generated by our system. Please keep this for your records.<br/>"
            "For any queries or support, please contact our team through the bot.<br/><br/>"
            "<i>This receipt serves as proof of your successful payment and membership activation.</i>",
            ParagraphStyle(
                'Footer',
                parent=styles['Normal'],
                fontSize=8.5,
                textColor=colors.HexColor('#6B7280'),
                alignment=TA_CENTER,
                leading=11
            )
        )
        story.append(footer_text)
        
        doc.build(story)
        
        logger.info(f"Receipt PDF generated: {filename}")
        return filename
        
    except Exception as e:
        logger.error(f"Error generating receipt PDF: {str(e)}")
        return None
