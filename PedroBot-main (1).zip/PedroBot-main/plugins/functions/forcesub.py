"""
Force subscribe functionality for LuffyBot.
Checks if users have joined required channels before using the bot.
"""

import logging
from pyrogram import enums
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from pyrogram.errors import UserNotParticipant

logger = logging.getLogger(__name__)


async def handle_force_subscribe(bot, message):
    """
    Check if user is subscribed to required channel.
    Returns 200 if user is subscribed, 400 if not.
    """
    try:
        from plugins.config import Config
        
        if not Config.UPDATES_CHANNEL:
            return 200
        
        user = message.from_user if hasattr(message, 'from_user') else message.message.from_user if hasattr(message, 'message') else None
        if not user:
            return 200
        
        try:
            member = await bot.get_chat_member(chat_id=Config.UPDATES_CHANNEL, user_id=user.id)
            
            if member.status in [enums.ChatMemberStatus.ADMINISTRATOR, enums.ChatMemberStatus.OWNER, enums.ChatMemberStatus.MEMBER]:
                return 200
        except UserNotParticipant:
            pass
        except Exception as e:
            logger.error(f"Error checking subscription: {str(e)}")
            return 200
        
        try:
            invite_link = await bot.create_chat_invite_link(chat_id=Config.UPDATES_CHANNEL)
            link = invite_link.invite_link
        except Exception as e:
            logger.error(f"Error creating invite link: {str(e)}")
            link = f"https://t.me/{Config.UPDATES_CHANNEL.replace('@', '')}"
        
        buttons = InlineKeyboardMarkup([
            [InlineKeyboardButton("🔔 Join Channel", url=link)],
            [InlineKeyboardButton("🔄 Check Subscription", callback_data="check_sub")]
        ])
        
        text = f"""
**👋 Hey {user.mention}!**

To use this bot, you must join our updates channel first.

**Please:**
1️⃣ Click the button below to join
2️⃣ Click "Check Subscription" after joining

Thank you! 💫
"""
        
        if hasattr(message, 'reply_text'):
            await message.reply_text(text=text, reply_markup=buttons, quote=True)
        elif hasattr(message, 'message'):
            await message.message.reply_text(text=text, reply_markup=buttons, quote=True)
        
        return 400
        
    except Exception as e:
        logger.error(f"Error in force subscribe: {str(e)}")
        return 200
